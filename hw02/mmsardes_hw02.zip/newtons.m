function [] = newtons(f, X_init_array1)
%NEWTONS Summary of this function goes here
%   Detailed explanation goes here

end

